# Portfolio Customization Guide

This guide explains how to customize your portfolio website content. The portfolio is now structured to make content updates easy and organized.

## Files to Modify for Content Changes

### 1. Personal Information and Content (`src/data/portfolioData.js`)

This is the **main file** you'll need to edit to update your portfolio content:

#### Personal Information
- **Name**: Update `personalInfo.name`
- **Title**: Update `personalInfo.title` (e.g., "AI Engineer & Developer")
- **Subtitle**: Update `personalInfo.subtitle` (the description under your title)

#### About Me Section
- **Paragraphs**: Edit the array `personalInfo.about.paragraphs`
- Add, remove, or modify paragraphs as needed

#### Education
- **Degree**: Update `personalInfo.education.degree`
- **Status**: Update `personalInfo.education.status`
- **Description**: Update `personalInfo.education.description`
- **Research Focus**: Update `personalInfo.education.researchFocus`
- **Courses**: Modify the `personalInfo.education.courses` array

#### Skills
- **Categories**: Modify the `personalInfo.skills` object
- Add new categories or update existing ones
- Each category contains an array of skills

#### Contact Information
- **GitHub**: Update `personalInfo.contact.github`
- **LinkedIn**: Update `personalInfo.contact.linkedin`
- **Email**: Update `personalInfo.contact.email`

#### Projects
- **Replace dummy projects** with your actual projects in the `projects` array
- For each project, update:
  - `name`: Project name
  - `description`: Project description
  - `topics`: Array of technologies/topics (shown as badges)
  - `githubUrl`: Link to GitHub repository
  - `liveUrl`: Link to live demo (set to `null` if no demo)
  - `featured`: Set to `true` to show on homepage

### 2. Styling and Colors (`src/App.css`)

The portfolio now uses a beautiful light color scheme. If you want to adjust colors:

- **Primary colors**: Look for `--primary`, `--chart-1`, `--chart-2`, etc.
- **Background gradients**: Modify `.hero-gradient` and `.gradient-section`
- **Card styling**: Adjust `.enhanced-card` for card appearance

### 3. Component Structure (`src/App.jsx`)

This file contains the React component structure. You typically won't need to modify this unless you want to:
- Add new sections
- Change the layout structure
- Modify component behavior

## Quick Start Guide

1. **Update your information**: Edit `src/data/portfolioData.js`
2. **Replace projects**: Update the `projects` array with your actual projects
3. **Test locally**: Run the development server to see your changes
4. **Deploy**: Push to GitHub Pages or your preferred hosting platform

## Example: Adding a New Project

```javascript
{
  id: 5,
  name: "Your Project Name",
  description: "Description of what your project does and the technologies used.",
  topics: ["react", "nodejs", "mongodb", "api"],
  githubUrl: "https://github.com/yourusername/your-project",
  liveUrl: "https://your-project-demo.com", // or null if no demo
  featured: true
}
```

## Example: Updating About Me

```javascript
about: {
  paragraphs: [
    "Your first paragraph about yourself and your background.",
    "Your second paragraph about your experience and interests.",
    "Your third paragraph about your goals and what you're looking for."
  ]
}
```

## Color Scheme

The portfolio uses a professional light color scheme with:
- **Soft pastels** for backgrounds
- **Gradient overlays** for visual interest
- **Subtle shadows** and **smooth transitions**
- **Colorful accents** for icons and interactive elements

The design is fully responsive and works well on both desktop and mobile devices.

## Need Help?

If you need to make more advanced customizations or encounter any issues, the portfolio structure is designed to be modular and easy to understand. The main content is separated from the presentation logic, making updates straightforward.

