// Personal Information Configuration
// Update this file to customize your portfolio content

export const personalInfo = {
  name: "Vedant",
  title: "AI Engineer & Developer",
  subtitle: "Recent MS in Artificial Intelligence graduate specializing in hallucination mitigation, GenAI applications, and intelligent systems that solve real-world problems.",
  
  // About Me Section
  about: {
    paragraphs: [
      "I'm a passionate AI engineer with a Master's degree in Artificial Intelligence, specializing in cutting-edge research and practical applications. My work focuses on making AI systems more reliable and effective.",
      "Over the past six months, I've been deeply involved in developing GenAI applications and intelligent agents, combining theoretical knowledge with hands-on implementation to create solutions that make a real impact.",
      "My research in hallucination mitigation addresses one of the most critical challenges in modern AI, working to improve the reliability and trustworthiness of large language models."
    ]
  },

  // Education Information
  education: {
    degree: "Master of Science in Artificial Intelligence",
    status: "Recently Graduated",
    description: "Comprehensive graduate program covering advanced AI concepts and practical applications.",
    researchFocus: "Hallucination Mitigation in Large Language Models",
    courses: [
      "Advanced Machine Learning",
      "Deep Learning",
      "Natural Language Processing", 
      "Cognitive Science",
      "Recommender Systems",
      "Reinforcement Learning",
      "MLOps",
      "Image Processing"
    ]
  },

  // Skills organized by category
  skills: {
    "AI/ML": ["Advanced Machine Learning", "Deep Learning", "Natural Language Processing", "Computer Vision", "Reinforcement Learning"],
    "Research": ["Hallucination Mitigation", "Cognitive Science", "MLOps", "Research Methodology"],
    "Development": ["GenAI Applications", "AI Agents", "Python", "TensorFlow", "PyTorch"],
    "Tools": ["Git", "Docker", "Jupyter", "Streamlit", "LangChain"]
  },

  // Contact Information
  contact: {
    github: "https://github.com/Vedant-1012",
    linkedin: "https://linkedin.com/in/vedant",
    email: "vedant@example.com"
  }
};

// Projects Configuration
// Replace these dummy projects with your actual projects
export const projects = [
  {
    id: 1,
    name: "AI Hallucination Mitigation",
    description: "Research project focused on reducing hallucinations in large language models through novel training techniques and validation methods.",
    topics: ["python", "pytorch", "nlp", "research"],
    githubUrl: "https://github.com/Vedant-1012",
    liveUrl: null, // Set to null if no live demo
    featured: true // Set to true for featured projects
  },
  {
    id: 2,
    name: "GenAI Application Suite",
    description: "Collection of generative AI applications including text generation, image synthesis, and multimodal AI agents for various use cases.",
    topics: ["python", "openai", "langchain", "streamlit"],
    githubUrl: "https://github.com/Vedant-1012",
    liveUrl: "https://example.com",
    featured: true
  },
  {
    id: 3,
    name: "Intelligent Recommender System",
    description: "Advanced recommendation engine using deep learning and collaborative filtering for personalized content delivery.",
    topics: ["python", "tensorflow", "machine-learning", "recommendation"],
    githubUrl: "https://github.com/Vedant-1012",
    liveUrl: null,
    featured: true
  },
  {
    id: 4,
    name: "Computer Vision Pipeline",
    description: "End-to-end computer vision solution for image processing, object detection, and real-time analysis applications.",
    topics: ["python", "opencv", "yolo", "computer-vision"],
    githubUrl: "https://github.com/Vedant-1012",
    liveUrl: null,
    featured: true
  }
];

