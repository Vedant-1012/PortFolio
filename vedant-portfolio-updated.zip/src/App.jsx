import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Github, Linkedin, Mail, ExternalLink, Brain, Code, Database, Cpu } from 'lucide-react'
import { personalInfo, projects as projectsData } from './data/portfolioData.js'
import './App.css'

function App() {
  const [projects, setProjects] = useState([])

  useEffect(() => {
    // Filter only featured projects
    const featuredProjects = projectsData.filter(project => project.featured)
    setProjects(featuredProjects)
  }, [])

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-sm border-b z-50">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-bold">{personalInfo.name}</h1>
            <div className="flex space-x-6">
              <a href="#about" className="text-muted-foreground hover:text-foreground transition-colors">About</a>
              <a href="#projects" className="text-muted-foreground hover:text-foreground transition-colors">Projects</a>
              <a href="#skills" className="text-muted-foreground hover:text-foreground transition-colors">Skills</a>
              <a href="#contact" className="text-muted-foreground hover:text-foreground transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6 hero-gradient">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-primary via-chart-1 to-chart-3 bg-clip-text text-transparent">
            {personalInfo.title}
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            {personalInfo.subtitle}
          </p>
          <div className="flex justify-center space-x-4">
            <Button asChild className="smooth-transition">
              <a href="#projects">View My Work</a>
            </Button>
            <Button variant="outline" asChild className="smooth-transition">
              <a href="#contact">Get In Touch</a>
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6 gradient-section">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-12 text-center">About Me</h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="w-64 h-64 bg-gradient-to-br from-primary/20 via-chart-1/20 to-chart-3/20 rounded-lg mx-auto mb-8 flex items-center justify-center enhanced-card">
                <Brain className="w-24 h-24 text-primary" />
              </div>
            </div>
            <div>
              {personalInfo.about.paragraphs.map((paragraph, index) => (
                <p key={index} className="text-lg text-muted-foreground mb-6">
                  {paragraph}
                </p>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-12 text-center">Education</h2>
          <Card className="mb-8 enhanced-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-primary" />
                {personalInfo.education.degree}
              </CardTitle>
              <CardDescription>{personalInfo.education.status}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                {personalInfo.education.description}
              </p>
              <div className="mb-4">
                <h4 className="font-semibold mb-2">Research Focus:</h4>
                <p className="text-muted-foreground">{personalInfo.education.researchFocus}</p>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Relevant Coursework:</h4>
                <div className="flex flex-wrap gap-2">
                  {personalInfo.education.courses.map((course, index) => (
                    <Badge key={index} variant="secondary" className="smooth-transition">{course}</Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-6 gradient-section">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-12 text-center">Skills & Expertise</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {Object.entries(personalInfo.skills).map(([category, skillList]) => (
              <Card key={category} className="enhanced-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {category === "AI/ML" && <Brain className="w-5 h-5 text-chart-1" />}
                    {category === "Research" && <Database className="w-5 h-5 text-chart-2" />}
                    {category === "Development" && <Code className="w-5 h-5 text-chart-3" />}
                    {category === "Tools" && <Cpu className="w-5 h-5 text-chart-4" />}
                    {category}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {skillList.map((skill, index) => (
                      <Badge key={index} variant="outline" className="smooth-transition hover:bg-primary/10">{skill}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-12 text-center">Featured Projects</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project) => (
              <Card key={project.id} className="enhanced-card">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    {project.name}
                    <div className="flex space-x-2">
                      <Button size="sm" variant="ghost" asChild className="smooth-transition hover:bg-primary/10">
                        <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                          <Github className="w-4 h-4" />
                        </a>
                      </Button>
                      {project.liveUrl && (
                        <Button size="sm" variant="ghost" asChild className="smooth-transition hover:bg-primary/10">
                          <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        </Button>
                      )}
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.topics.map((topic, index) => (
                      <Badge key={index} variant="secondary" className="smooth-transition">{topic}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6 gradient-section">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-12">Let's Connect</h2>
          <p className="text-xl text-muted-foreground mb-8">
            I'm always interested in discussing AI, technology, and new opportunities.
          </p>
          <div className="flex justify-center space-x-6">
            <Button size="lg" asChild className="smooth-transition">
              <a href={personalInfo.contact.github} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                <Github className="w-5 h-5" />
                GitHub
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild className="smooth-transition">
              <a href={personalInfo.contact.linkedin} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                <Linkedin className="w-5 h-5" />
                LinkedIn
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild className="smooth-transition">
              <a href={`mailto:${personalInfo.contact.email}`} className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                Email
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t">
        <div className="max-w-4xl mx-auto text-center text-muted-foreground">
          <p>&copy; 2025 {personalInfo.name}. Built with React and passion for AI.</p>
        </div>
      </footer>
    </div>
  )
}

export default App

